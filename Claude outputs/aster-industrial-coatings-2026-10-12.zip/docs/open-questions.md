# Open Questions and Decision Register

**Project:** Aster Industrial Coatings website · **Updated:** 2026-10-12

This is the single list of things the owner must decide or supply. Each item carries a priority:

- **BLOCK** — Blocking launch. The site cannot go live without this.
- **PUB** — Important before content publication. Development can proceed with placeholders; the affected pages stay unpublished (`noindex`, excluded from sitemap, or not built) until answered.
- **LATER** — Can be resolved after initial development.

Development is **not** blocked by any of these. Every page and component is being built so that the answer drops into one place (the brand configuration file or a content file) without re-editing pages.

How to answer: reply inline, or fill the table in section H. Where a question asks for documents, attach them or share a folder.

---

## A. Company identity

| ID | Question | Why it matters | Priority | Default until answered |
|---|---|---|---|---|
| A1 | Final company name. | Everything. | **DECIDED** | **Aster Industrial Coatings** (owner, 2026-10-12). Knockout screen in `naming-research.md` §5: no live US paint/coatings mark; one live ASTER in Class 2 for toner cartridges and a Japanese "Aster Power Coating" seismic product to flag to counsel. Attorney clearance still recommended before filing. |
| A2 | Approved tagline (if any)? | Hero and metadata. | PUB | None shown; hero uses a descriptive statement of what is supplied |
| A3 | Legal entity name, type and state of formation? | Footer, privacy policy, terms, Organization schema `legalName`. | **BLOCK** | `[LEGAL ENTITY TBD]` |
| A4 | What is the relationship to Sunpol? (Sister company, division, distributor of Sunpol-based products, shared ownership, supplier only?) Which Sunpol: public directories list "Sun Polymers International Inc." (Mooresville, IN, powder-coating resins and additives; parent Chan Sieh Enterprises) and "Sunpol Resins & Polymers" (alkyd resins). Neither has been confirmed as the related entity. | Determines whether and how the site may reference Sunpol, whether a shared HubSpot portal is appropriate, and whether any Sunpol capabilities can be described as the new company's. | **BLOCK** | No reference to Sunpol on public pages |
| A5 | Public business address (and whether it should be published)? | Contact page, footer, Organization/LocalBusiness schema, Google Business Profile. | **BLOCK** | `[ADDRESS TBD]`; LocalBusiness schema omitted |
| A6 | Approved sales phone number and email address(es)? Separate technical-support contact? | Header, footer, contact, confirmation emails, `tel:`/`mailto:` click tracking. | **BLOCK** | `[PHONE TBD]`, `[EMAIL TBD]` |
| A7 | Target service regions (US only? Canada? Mexico? specific states)? Shipping restrictions? | Copy, structured data `areaServed`, RFQ "project location" field options, hreflang (none expected). | PUB | United States |
| A8 | Approved one-paragraph company description. | About page, meta descriptions, Organization schema, email signatures. | PUB | Descriptive placeholder flagged `[OWNER COPY NEEDED]` |
| A9 | Business hours and time zone? | Contact page, schema `openingHours`. | LATER | Omitted |
| A10 | Logo files (SVG preferred) and any existing brand colours? | Header, favicon, OG image, design tokens. | PUB | Wordmark set in the design-system typeface |

## B. Business model

| ID | Question | Why it matters | Priority | Default |
|---|---|---|---|---|
| B1 | Is the company a manufacturer, formulator, toll manufacturer, distributor, or a combination? | The single most important positioning fact. "Manufacturer" cannot be claimed if products are sourced. | **BLOCK** | Copy says "supplies" and avoids "manufactures" |
| B2 | Which products are made in-house vs sourced? Who makes the sourced ones (and may they be named)? | Product-page wording, Quality page, "made in USA" statements. | PUB | No origin statements |
| B3 | Custom formulation / colour-matching capability? Turnaround? | A key differentiator if true; must not be implied otherwise. | PUB | Not mentioned |
| B4 | Minimum order quantities (by product or general)? | RFQ volume field thresholds; FAQ. | LATER | Not published; RFQ captures estimated volume |
| B5 | Packaging formats offered (e.g. 1 gal, 5 gal pail, 55 gal drum, totes)? | Product content model `packaging` field. | PUB | Field omitted on product pages when empty |
| B6 | Production/supply capacity statements that can be made publicly? | Trust layer; avoid overclaiming. | LATER | None |
| B7 | Standard lead times for stock, custom colour, samples? | Published commitments are persuasive; must be achievable. | PUB | Not published |
| B8 | Shipping regions and carriers; hazmat shipping constraints? | Copy, RFQ location options. | LATER | Not published |
| B9 | Sales process: direct sales, reps, distributors? Any need for a "find a rep" feature or distributor portal? | IA and possible future features. | PUB | Direct inquiry only |
| B10 | Do you want to publish prices? (Recommendation: no.) | Scope. | LATER | No pricing |

## C. Products

| ID | Question | Why it matters | Priority | Default |
|---|---|---|---|---|
| C1 | Official product names and codes for the launch catalog. | Product pages cannot exist without them. | **BLOCK** (for the Products section; the rest of the site can launch without products only if the owner accepts a "catalog coming" state — not recommended) | No product pages built/indexed |
| C2 | Product categories you want buyers to see (e.g. primers, topcoats, DTM, water-based, solvent-based, specialty)? | Navigation and URL structure. | PUB | Two-axis taxonomy: chemistry/system type × function (primer/topcoat/etc.) |
| C3 | For each product: intended uses, suitable substrates, limitations. | Core product content; also powers the selector. | PUB | Fields show "Not specified" rather than invented values |
| C4 | Available technical specifications per product (solids by volume, VOC, recommended DFT, dry/cure times, gloss, application methods, thinning, coverage, shelf life, etc.). Which may be published? | Spec tables; structured data `additionalProperty`. | PUB | Table omitted when empty |
| C5 | Where do spec values come from (TDS) and who signs off on their accuracy? | Liability; review workflow. | PUB | Each product has a `reviewedBy`/`reviewedAt` field required before `status: published` |
| C6 | Packaging and availability per product. | Product page. | LATER | Omitted |
| C7 | TDS and SDS documents approved for public distribution (PDF). Versioning/revision dates? | Technical Resources section; a primary differentiator. Recommendation: keep SDS ungated (customers and distributors need ready access; hazard-communication rules require supplying SDS downstream, and ungated web access is the simplest way to meet that expectation). | PUB | No documents listed |
| C8 | Certifications or compliance statements per product (e.g. VOC category compliance, heavy-metal-free, specific standards met) **with supporting evidence**. | Attribute badges and Quality page. Unsupported badges are a liability. | PUB | No badges |
| C9 | Product imagery (packaging shots, application photos) with usage rights. | Product cards/pages, OG images. | PUB | Neutral generated placeholder graphic clearly not implying a facility or product |
| C10 | Colour offering: stock colours, custom match, colour standards (RAL, Federal Standard, custom)? | Possible colour section; RFQ field. | LATER | Not shown |

## D. Target customers

| ID | Question | Why it matters | Priority | Default |
|---|---|---|---|---|
| D1 | Priority industries (rank top 3–6). | Industry pages, homepage, keyword map. | PUB | Generic "metal fabrication and OEM" language; no industry pages published |
| D2 | Ideal customer profile (company size, type, line setup: spray, dip, bake?). | Copy tone and RFQ fields. | PUB | — |
| D3 | Typical buyers and decision-makers (engineer, plant manager, purchasing, owner)? | Messaging, form field choices. | LATER | Mixed audience |
| D4 | Common customer problems you solve. | Application and homepage copy; FAQ. | PUB | — |
| D5 | Common objections (price, switching cost, approvals, lead time)? | FAQ and sales-enablement content. | LATER | — |
| D6 | Geographic priorities within the service region. | Local SEO decisions. | LATER | None |
| D7 | Typical order sizes (optional). | RFQ volume options; lead scoring. | LATER | Generic ranges |
| D8 | Lead qualification criteria (what makes a lead worth a salesperson's time?). | RFQ required fields; CRM lead scoring; analytics definitions. | PUB | Business email + company + product/application interest |

## E. Commercial process

| ID | Question | Why it matters | Priority | Default |
|---|---|---|---|---|
| E1 | Who receives new quote inquiries (names/emails)? Backup? | Internal notification routing. | **BLOCK** | `SALES_NOTIFICATION_EMAIL` env var, unset |
| E2 | Who answers technical inquiries? | Routing of the technical form. | **BLOCK** | `TECHNICAL_NOTIFICATION_EMAIL` env var, unset |
| E3 | Who prepares quotes, and what information do they need to quote without a follow-up call? | Determines RFQ fields. | PUB | Fields in `docs/lead-generation-plan.md` §3 |
| E4 | Expected response time you are willing to publish. | Trust signal; sets customer expectation in confirmation email. | PUB | "We will respond as soon as possible" (no commitment) |
| E5 | CRM platform decision: HubSpot? Separate portal or segmented existing portal? Who administers it? | Integration design and credentials. | PUB (BLOCK for CRM integration specifically) | Mock adapter; leads stored durably + emailed |
| E6 | Sales territories or routing rules (by region, industry, product)? | CRM owner assignment. | LATER | Single owner |
| E7 | Lead qualification process after capture (who calls, when, SLA)? | Analytics definitions of "qualified lead" and "opportunity". | LATER | Documented defaults in `docs/lead-generation-plan.md` |

## F. Technology

| ID | Question | Why it matters | Priority | Default |
|---|---|---|---|---|
| F1 | Domain. | Canonical URL, email sending domain, redirects. | **DECIDED** | Owner holds **asterpaint.net** and **astercoatings.net** (registered 2026-10-09). Recommend **astercoatings.net** as canonical (matches the company name) with asterpaint.net 301-redirecting to it. astercoatings.com and aster-coatings.com are held by a Dutch registrant since 2014; asterpaint.com is an unrelated Chinese site. **asterindustrialcoatings.com, asterindustrial.com and asterpaints.com were unregistered on 2026-10-12** — worth registering defensively if the owner wishes (not done; rule 15). |
| F2 | Hosting preference (Vercel, Netlify, Cloudflare, AWS, existing provider)? Any IT policy constraints? | Deployment process, edge/runtime choices, cost. | PUB | Vercel-compatible build; also documented for Node self-host |
| F3 | Email sending: existing transactional provider (e.g. SES, Postmark, SendGrid, Microsoft 365 SMTP)? Which domain sends? | Confirmation and notification emails; SPF/DKIM/DMARC. | **BLOCK** | Email adapter with console/mock transport |
| F4 | HubSpot: portal ID, private-app access, which pipeline/objects to use (Deals vs Tickets vs custom "Inquiry" object)? | Live CRM integration. | PUB | Mock adapter |
| F5 | Analytics: GA4 acceptable? Existing Google account/property? Search Console access? Consent-management preferences? | Measurement; consent banner behaviour. | PUB | GA4 code path present but disabled until `NEXT_PUBLIC_GA_MEASUREMENT_ID` set; consent required before load |
| F6 | Budget for paid services (hosting, email, forms storage, CAPTCHA, uptime monitoring)? | Service selection. | PUB | Free tiers / none |
| F7 | Content management: will non-developers need to edit products/pages? If yes, how often? | Whether to add a Git-based CMS layer now or later. | LATER | Typed content files in repo; CMS evaluated post-launch |
| F8 | Who maintains the site after launch (internal, agency, this engagement)? | Documentation depth, CI setup, dependency update policy. | LATER | Full README + runbooks |
| F9 | GitHub repository URL (owner creates an empty repo). | Code delivery. | **BLOCK for code delivery** | Code held in workspace until provided |
| F10 | Privacy/legal: who reviews the privacy policy and consent language? Any regulated-state obligations (e.g. California) or Canadian/EU visitors expected? | Legal pages and consent gating. | **BLOCK** | Draft policy flagged `[LEGAL REVIEW REQUIRED]` |

## G. Items already decided

| Date | Decision | By |
|---|---|---|
| 2026-10-09 | This session delivers discovery and planning only; code begins after architecture approval. | Owner |
| 2026-10-09 | Code will be delivered to a GitHub repository (URL pending). | Owner |
| 2026-10-09 | Provisional brand "Vantrex Coatings" used in development with configuration-level replaceability. | Brief |
| 2026-10-09 | Name knockout screen completed; "Vantrex" flagged as unlikely to clear; shortlist produced (`docs/naming-research.md`). | Research |
| 2026-10-12 | **Company name: Aster Industrial Coatings.** Domains held: asterpaint.net, astercoatings.net. All docs updated from the Vantrex placeholder. Attorney clearance still to be obtained. | Owner |

## H. Quick answer sheet

Copy, fill and return. Leave blank anything unknown.

```
A1 Final name / cleared?        : Aster Industrial Coatings / attorney clearance pending
A3 Legal entity                 :
A4 Relationship to Sunpol       :
A5 Public address               :
A6 Phone / sales email / tech email :
A7 Service regions              :
B1 Manufacturer / formulator / distributor :
B3 Custom formulation?          :
B5 Packaging formats            :
B7 Lead times (stock / custom / sample) :
C1 Product list (attach)        :
C7 TDS/SDS approved (attach)    :
C8 Certifications (attach evidence) :
D1 Top industries               :
D8 Lead qualification criteria  :
E1 Quote inquiry recipient(s)   :
E2 Technical inquiry recipient(s) :
E4 Response-time commitment     :
E5 HubSpot portal: separate / segmented / other :
F1 Domain                       : astercoatings.net (canonical?) + asterpaint.net
F2 Hosting                      :
F3 Email provider & sending domain :
F5 GA4 ok? Search Console owner :
F9 GitHub repo URL              :
F10 Legal reviewer              :
```
