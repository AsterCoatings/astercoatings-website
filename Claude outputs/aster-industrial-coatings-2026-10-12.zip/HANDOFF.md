# Aster Industrial Coatings — website project handoff

**Packaged:** 2026-10-12 · **Phase:** Discovery and planning complete; no code written yet (by owner decision, code begins after architecture approval).

## What is in this zip

`docs/` — the ten project documents, all current as of 2026-10-12:

| File | Purpose |
|---|---|
| `README.md` | Index of the documentation set and how the documents relate |
| `initial-requirements.md` | Scope, verified facts, functional and non-functional requirements, operating rules |
| `competitive-research.md` | Audit of two reference competitor sites and the gaps Aster can fill |
| `technical-architecture.md` | Proposed stack, information architecture, content model, integrations (awaiting owner approval) |
| `implementation-plan.md` | Phased build plan tied to the architecture |
| `seo-strategy.md` | Technical and content SEO plan |
| `lead-generation-plan.md` | RFQ flow, lead capture, CRM hand-off |
| `launch-checklist.md` | Pre-launch template (nothing checked yet) |
| `naming-research.md` | Four rounds of name screening plus §5, the knockout screen of the chosen name |
| `open-questions.md` | Every open decision with priority and default; §H is a fill-in answer sheet |

## Where things stand

- **Name decided:** Aster Industrial Coatings (2026-10-12). Domains held: asterpaint.net, astercoatings.net. Recommended canonical: astercoatings.net. Attorney clearance still pending; see `naming-research.md` §5 for what to brief counsel on (a live ASTER toner-cartridge mark in Class 2; Aster Co., Ltd. of Japan's "Aster Power Coating").
- **Blocking questions still open** (`open-questions.md`, marked BLOCK): legal entity (A3), relationship to Sunpol (A4), public address (A5), phone/email (A6), manufacturer vs distributor (B1), product list (C1), approved TDS/SDS (C7), quote recipients (E1), GitHub repo URL (F9), legal reviewer (F10).
- **Next milestone:** owner approves `technical-architecture.md`, then code begins and is delivered to the GitHub repo named in F9.

## Continuing on the Mac

Everything here is also saved in the Claude project "Industrial Coatings Website", which is available from any device signed in to the same account — open the project on the Mac and the docs and this conversation's history are there. This zip is a plain-file backup of the same material; unzip it into a folder, connect that folder in the Claude desktop app, and work can continue against the files directly.
